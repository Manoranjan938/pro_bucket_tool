import React from "react";

import "./TaskAndBug.css";

const TeamTaskAndBugList = () => {
  return (
    <>
      <div className="task_and_bug_container">
        <div className="task_list">
            <h1>Task List</h1>
        </div>
        <div className="bug_list">
            <h1>Bug List</h1>
        </div>
      </div>
    </>
  );
};

export default TeamTaskAndBugList;
