import React from 'react'

import './Offer.css'

const Offer = () => {
    return (
        <div>
            <h1>Offer Card</h1>
        </div>
    )
}

export default Offer
