export const data = [
    {
      name: 'Monday',
      hours: 2400,
      amt: 2400,
    },
    {
      name: 'Tuesday',
      hours: 1398,
      amt: 2210,
    },
    {
      name: 'Wednesday',
      hours: 9800,
      amt: 2290,
    },
    {
      name: 'Thursday',
      hours: 3908,
      amt: 2000,
    },
    {
      name: 'Friday',
      hours: 4800,
      amt: 2181,
    },
    {
      name: 'Saturday',
      hours: 3800,
      amt: 2500,
    },
    {
      name: 'Sunday',
      hours: 4300,
      amt: 2100,
    },
  ];