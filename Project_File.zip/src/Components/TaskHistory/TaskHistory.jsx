import React from 'react'

const TaskHistory = () => {
  return (
    <div>TaskHistory</div>
  )
}

export default TaskHistory