import React from 'react'

const Bugs = () => {
  return (
    <div>Bugs</div>
  )
}

export default Bugs