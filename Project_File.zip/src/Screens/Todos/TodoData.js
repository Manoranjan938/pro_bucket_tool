export const TodoData = [
    {
        title: "Need to add the interested button",
        id: 1,
        status: "pending",
        isAddedToTask: false
    },
    {
        title: "Email thing need to clean up and update all the things",
        id: 2,
        status: "pending",
        isAddedToTask: false
    },
    {
        title: "redis server things i need to add",
        id: 3,
        status: "pending",
        isAddedToTask: false
    },
    {
        title: "Image upload and video upload and document upload",
        id: 4,
        status: "done",
        isAddedToTask: false
    },
    {
        title: "Need to update like and dislike api",
        id: 5,
        status: "pending",
        isAddedToTask: false
    },
    {
        title: "Make a api for get the user details after logged in",
        id: 6,
        status: "done",
        isAddedToTask: false
    },
    {
        title: "Need to integrate the sign up page",
        id: 7,
        status: "pending",
        isAddedToTask: false
    },
    {
        title: "Need to integrate like and dislike ",
        id: 8,
        status: "done",
        isAddedToTask: false
    },
    {
        title: "Need to make the pagination workable",
        id: 9,
        status: "pending",
        isAddedToTask: false
    },
    {
        title: "Need to make the insertPrice api",
        id: 10,
        status: "done",
        isAddedToTask: false
    },
    {
        title: "Need to update the contact us api",
        id: 11,
        status: "done",
        isAddedToTask: false
    },
    {
        title: "pending amount details i did need to check",
        id: 12,
        status: "done",
        isAddedToTask: false
    },
    {
        title: "Need to add getLikes and dislikes by userid",
        id: 13,
        status: "pending",
        isAddedToTask: false
    },
]