import Profile from 'Components/UserProfile/Profile'
import React from 'react'

const UserProfile = () => {
  return (
    <>
      <Profile />
    </>
  );
}

export default UserProfile