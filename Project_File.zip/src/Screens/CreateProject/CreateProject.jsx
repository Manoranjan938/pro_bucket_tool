import NewProject from 'Components/NewProject/NewProject';
import React from 'react'

const CreateProject = () => {
    return (
      <>
        <NewProject />
      </>
    );
}

export default CreateProject
