import React from 'react'
import Helmet from 'react-helmet'

const TeamIssue = () => {
  return (
    <>
    <Helmet>
        <title>Team Dashboard | Issues</title>
    </Helmet>
    </>
  )
}

export default TeamIssue